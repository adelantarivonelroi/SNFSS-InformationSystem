<?php 

  $page_title="Sto. Nino Formation and Science ";
  include_once( '../../includes/header.php');
  //include ('../../config.php');

  validateAccess();
  validateDepartmentHead();

  $disabled = "disabled"; //for section dropdown and button
  $displaymessage = "";
  $message = "";

  #get school year
  $sql_sy = $con->prepare("SELECT SchoolYearID, SchoolYearStart, SchoolYearEnd FROM schoolyear ORDER BY SchoolYearID DESC LIMIT 1");
  $sql_sy->execute();
  $result_sy = $sql_sy->get_result();
  $list_sy = "";
  while ($row = mysqli_fetch_array($result_sy))
  {
    $syid = $row['SchoolYearID'];
    $systart = $row['SchoolYearStart'];
    $syend = $row['SchoolYearEnd'];
  }

  #get section
  $sql_section = $con->prepare("SELECT SectionID, LevelID, SectionName FROM section WHERE SectionStatus = 'Approved' ORDER BY LevelID");
  $sql_section->execute();
  $result_section = $sql_section->get_result();

  $list_section = "";
  while ($row = mysqli_fetch_array($result_section))
  {
    $secid = $row['SectionID'];
    $seclevelid = $row['LevelID'];
    $secnumber = $row['SectionName'];
    $list_section .= "<option value='$secid'>$seclevelid - $secnumber</option>";
  }

  #get time
  $sql_time = $con->prepare("SELECT TimeSlotID, TimeCode, TimeForm FROM timeslot ORDER BY TimeCode ASC");
  $sql_time->execute();
  $result_time = $sql_time->get_result();
  $list_time = "";
  while ($row = mysqli_fetch_array($result_time))
  {
    $timeid= $row['TimeSlotID'];
    $timeform = $row['TimeForm'];
    $list_time .= "<option value='$timeid'>$timeform</option>";
  }

  if (isset($_SESSION['sectionid']) && !empty($_SESSION['sectionid']) && isset($_SESSION['levelid']) && !empty($_SESSION['levelid']) && isset($_SESSION['sectionno']) && !empty($_SESSION['sectionno']))
  {
    $csid = $_SESSION['sectionid'];
    $lvlses = $_SESSION['levelid'];
    $snses = $_SESSION['sectionno'];

    $sql_viewselected = $con->prepare("SELECT fl.FacultyListID, fl.SectionID, fl.LevelID, s.SectionName, fl.Status, su.SubjectName, ts.TimeForm, u.FirstName, u.MiddleName, u.LastName
    FROM facultylist fl
    INNER JOIN schoolyear sy
    ON fl.SchoolYearID = sy.SchoolYearID
    INNER JOIN level l 
    ON fl.LevelID = l.LevelID
    INNER JOIN section s 
    ON fl.SectionID = s.SectionID
    INNER JOIN teacher t 
    ON fl.TeacherID = t.TeacherID
    INNER JOIN user u
    ON t.UserID = u.UserID
    INNER JOIN subject su
    ON t.SubjectID = su.SubjectID
    INNER JOIN timeslot ts
    ON fl.TimeSlotID = ts.TimeSlotID 
    WHERE fl.Status = 'Temporary' AND fl.SectionID = $csid ORDER BY ts.TimeCode ASC");
    $sql_viewselected->execute();
    $result_templistselect = $sql_viewselected->get_result();

    $displaymessage = "Currently assigning faculty to section " . $lvlses . "-" . $snses;
  }
  else
  {
    #TEMP LIST
    $sql_templist = $con->prepare("SELECT fl.FacultyListID, su.SubjectName, fl.LevelID, s.SectionName, ts.TimeForm, u.FirstName, u.MiddleName, u.LastName
      FROM facultylist fl
      INNER JOIN schoolyear sy
      ON fl.SchoolYearID = sy.SchoolYearID
      INNER JOIN level l 
      ON fl.LevelID = l.LevelID
      INNER JOIN section s 
      ON fl.SectionID = s.SectionID
      INNER JOIN teacher t 
      ON fl.TeacherID = t.TeacherID
      INNER JOIN user u
      ON t.UserID = u.UserID
      INNER JOIN subject su
      ON t.SubjectID = su.SubjectID
      INNER JOIN timeslot ts
      ON fl.TimeSlotID = ts.TimeSlotID

      WHERE fl.Status = 'Temporary' ORDER BY ts.TimeCode ASC");
    $sql_templist->execute();
    $result_templistselect = $sql_templist->get_result();
    $displaymessage = "Currently viewing all assigned faculties";
  }
  


  #get faculty available
  $sql_teacherlist = $con->prepare("SELECT t.TeacherID, u.FirstName AS teaFirstName, u.MiddleName AS teaMiddleName, u.LastName AS teaLastName, s.SubjectName 
  FROM teacher t 
  INNER JOIN user u 
  ON t.UserID = u.UserID 
  INNER JOIN subject s 
  ON t.SubjectID = s.SubjectID 
  WHERE u.Status = 'Active'");
  $sql_teacherlist->execute();
  $result_teacher = $sql_teacherlist->get_result(); 

  if ( isset($_POST['viewsectionfl']))
  {

    $selectsec = mysqli_real_escape_string($con, $_POST['listsection']);

    $_SESSION['sectionid'] = $selectsec;

    $sql_getsection = $con->prepare("SELECT LevelID, SectionName FROM section WHERE SectionID = ?");
    $sql_getsection->bind_param('i', $selectsec);
    $sql_getsection->execute();
    $result_getsection = $sql_getsection->get_result();

    while ( $row = mysqli_fetch_array($result_getsection))
    {
      $lvl = $row['LevelID'];
      $sno = $row['SectionName'];

      $_SESSION['levelid'] = $lvl;
      $_SESSION['sectionno'] = $sno;
    }

    $sql_view = $con->prepare("SELECT fl.FacultyListID, fl.SectionID, fl.LevelID, s.SectionName, fl.Status, su.SubjectName, ts.TimeForm, u.FirstName, u.MiddleName, u.LastName
    FROM facultylist fl
    INNER JOIN schoolyear sy
    ON fl.SchoolYearID = sy.SchoolYearID
    INNER JOIN level l 
    ON fl.LevelID = l.LevelID
    INNER JOIN section s 
    ON fl.SectionID = s.SectionID
    INNER JOIN teacher t 
    ON fl.TeacherID = t.TeacherID
    INNER JOIN user u
    ON t.UserID = u.UserID
    INNER JOIN subject su
    ON t.SubjectID = su.SubjectID
    INNER JOIN timeslot ts
    ON fl.TimeSlotID = ts.TimeSlotID 
    WHERE fl.Status = 'Temporary' AND fl.SectionID = ?");
    $sql_view->bind_param('i', $selectsec);
    $sql_view->execute();
    $result_templistselect = $sql_view->get_result();

    $displaymessage = "Currently assigning faculty to section " . $lvl . "-" . $sno;
  }

  if ( isset ($_POST['assign']))
  {
    if (isset($_SESSION['sectionid']) && !empty($_SESSION['sectionid']))
    {
      if (isset($_POST['tradio']) && !empty($_POST['tradio']) && isset($_POST['assigntime']) && !empty($_POST['assigntime']))
      {
        $radioselect = mysqli_real_escape_string($con, $_POST['tradio']);
        $timeslot = mysqli_real_escape_string($con, $_POST['assigntime']);
        $section = $_SESSION['sectionid'];
        $level = $_SESSION['levelid'];

        $sql_checkdouble = $con->prepare("SELECT * FROM facultylist WHERE TimeSlotID = ?");
        $sql_checkdouble->bind_param('i', $timeslot);
        $sql_checkdouble->execute();
        $result_checkdouble = $sql_checkdouble->get_result();
        
        if ( mysqli_num_rows($result_checkdouble) > 0 )
        {
          $message = "Faculty was already assigned to that time. Select another.";
        }
        else 
        {
          $sql_addtemp = $con->prepare("INSERT INTO  facultylist ( SchoolYearID, LevelID, SectionID, TeacherID, TimeSlotID, Status ) VALUES ( $syid, $level, $section, $radioselect, $timeslot, 'Temporary')");  
          $sql_addtemp->bind_param('iiiii', $syid, $level, $section, $radioselect, $timeslot);
          $sql_addtemp->execute();
          $message = "Successfully added faculty to temporary list";
          echo "<script type='text/javascript'>alert('$message');</script>";
          header('location: facultylistcreate.php');
        }
      }
      else
      {
        $message = "Please select a faculty and a time slot to assign.";
      }
    }
    else 
    {
      $message = "Please select a section to assign first.";
    }
  }

  if ( isset ($_POST['remove']))
  {
    $fcheckboxes = isset($_POST['fcheck_box']) ? $_POST['fcheck_box'] : array();
    if(!empty($fcheckboxes)) 
    {
      foreach ($fcheckboxes as $fselected) 
      {
        $sql_delete = $con->prepare("DELETE FROM facultylist WHERE FacultyListID = ?");
        $sql_delete->bind_param('i', $fselected);
        $sql_delete->execute();
        $message = "Successfully removed from the list";
        header('location: facultylistcreate.php');
      }
    }
    else
    {
      $message = "Please select an assigned faculty first to remove.";
    }
  }

  if (isset($_POST['propose'])) 
  {
      while ($row = mysqli_fetch_array($result_templistselect)) 
      {
        $sql_propose = $con->prepare("UPDATE facultylist SET DateCreated = NOW(), Status = 'Pending' WHERE Status = 'Temporary'");
        $sql_propose->execute();
        $message = "Successfully submitted to be approved.";
        header('location: facultylistcreate.php');
      }
  }

  if (isset($_POST['back'])) 
  {
    header('location: facultylisthome.php');
  }

?>
<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu" data-widget="tree">
            <li class="header">Index</li>
            <li><a href="index.php"><i class="fa fa-circle-o text-red"></i> <span>Home</span></a></li>
            <li class="header">Faculty list</li>
            <li><a href="facultylisthome.php"><i class="fa fa-circle-o text-red"></i> <span>Manage Faculty list</span></a></li>
            <li class="header">Student list</li>
            <li><a href="studentlisthome.php"><i class="fa fa-circle-o text-red"></i> <span>Manage Student list</span></a></li>
            <li class="header">Sections</li>
            <li><a href="sectionhome.php"><i class="fa fa-circle-o text-red"></i> <span>Manage Sections</span></a></li>
            <li class="header">Student Record</li>
            <li><a href="studentrecordsearch.php"><i class="fa fa-circle-o text-red"></i> <span>View Student Record</span></a></li>
          </ul>
          </section>
          <!-- /.sidebar -->
        </aside> 
                

<!-- Content Wrapper. Contains page content -->

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Create faculty list
        <small>assign class</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Assign class</a></li>
        <li class="active">create faculty list</li>
      </ol>
    </section>



    <!-- Main content -->
    <form method="POST" class="form-horizontal">
    <section class="content">
      <div class="row">
        <!-- left column -->
          <div class="col-md-12">


	          <div class="box box-primary">
	              <div class="box-header">
                  <h3 class="box-title">Functions</h3>
                </div>

                <div class="box-body with-border border-bottom">

                  <div class="form-group">
                    <p class="col-sm-2 control-label">School year</p>
                    <div class="col-sm-2">
                      <label class="form-control"><?php echo $systart . " - " . $syend ?></label>
                    </div>
                    <div class="col-sm-2">
                      <button name='back' type='submit' class='btn btn-default'>
                        Back
                      </button>
                    </div>
                  </div>

                  <div class="form-group">
                    <p class="col-sm-2 control-label">Select section</p>
                    <div class="col-sm-2">
                      <select name="listsection" class="form-control">
                        <?php echo $list_section; ?>
                      </select>
                    </div>
                    <div class="col-sm-2">
                      <button name='viewsectionfl' type='submit' class='btn btn-primary'>
                        Select
                      </button>
                    </div>
                  </div>

                  <hr>

                  <div class="form-group">
                    <p class="col-sm-2 control-label">Select time slot to assign</p>

                    <div class="col-sm-2">
                      <div class="input-group">
                        <select name="assigntime" class="form-control">
                          <?php echo $list_time; ?>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <p class="col-sm-2 control-label"></p>
                    <div class="col-sm-3">
                      <button name='assign' type='submit' class='btn btn-primary'>
                        Assign
                      </button>
                      <button name='remove' type='submit' class='btn btn-danger'>
                        Remove
                      </button>
                      <button name='propose' type='submit' class='btn btn-success'>
                        Submit
                      </button>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label">
                      <?php echo $displaymessage ?>
                    </label>
                    <label class="col-sm-3 control-label">
                      <?php echo $message ?>
                    </label>
                  </div>
                </div>
            </div>
           
	          <div class="box box-primary">
              <div class="box-header with-border border-bottom">
                <h3 class="box-title">Faculty List</h3>
              </div>
              <!-- /.box-header -->
                <div class="box-body with-border">
                   <table id="example3" class="text-center table table-bordered table-striped">
                      <thead>
                        <th></th>
                        <th>Section</th>
                        <th>Faculty name</th>
                        <th>Subject</th>
                        <th>Time</th>
                      </thead>
                      <tbody>
                        <?php
    	                      while ($row = mysqli_fetch_array($result_templistselect))
    	                      {
    	                        $tmptid = $row['FacultyListID'];
                              $tmplevel = $row['LevelID'];
                              $tmpsection = $row['SectionName'];
    	                        $tmpsn = $row['SubjectName'];
    	                        $tmpfn = $row['FirstName'];
    	                        $tmptmn = $row['MiddleName'];
    	                        $tmptln = $row['LastName'];
    	                        $tmptf = $row['TimeForm'];

    	                        echo "
    	                          <tr>
                                  <td><input type='checkbox' name='fcheck_box[]' value='$tmptid' /></td>
                                  <td>$tmplevel - $tmpsection</td>
    	                            <td>$tmptln, $tmpfn $tmptmn</td>
    	                            <td>$tmpsn</td>
    	                            <td>$tmptf</td>
    	                          </tr>
    	                        ";
    	                      }
                        ?>
                      </tbody>
                    </table>
            	</div>
            </div>
          	  
	        <div class="box box-primary">
              <div class="box-header with-border border-bottom">
                <h3 class="box-title">Faculty available</h3>
              </div>
              <!-- /.box-header -->
              <div class="box-body with-border">
                 <table id="example3" class="text-center table table-bordered table-striped">
                    <thead>
                      <th></th>
                      <th>Subject</th>
                      <th>Faculty name</th>

                    </thead>
                     <tbody>
                      <?php
  	                      while ($row = mysqli_fetch_array($result_teacher))
  	                      {
  	                        $tid = $row['TeacherID'];
  	                        $sn = $row['SubjectName'];
  	                        $tfn = $row['teaFirstName'];
  	                        $tmn = $row['teaMiddleName'];
  	                        $tln = $row['teaLastName'];

  	                        echo "
  	                          <tr>
                                <td><input type='radio' name='tradio' value='$tid' /></td>
  	                            <td>$sn</td>
  	                            <td>$tln, $tfn $tmn</td>
  	                          </tr>
  	                        ";
  	                      }

                      ?>
                    </tbody>
                  </table>
              </div>
            </div>
          </div>
      </div>
    </section>
    </form>
    <!-- /.content -->
  <!-- /.content-wrapper -->

<?php
    include_once('../../includes/footer.php');
?>